
package cw1;

/**
 *
 * @author csf18onc
 */

 
import java.util.LinkedList;
 
public class CW1 {
    public static void main(String[] args)
        throws InterruptedException
    {
     
        final PC pc = new PC();
 
        //Ambulance Porter thread
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run()
            {
                try {
                    pc.ambulancePorter();
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
 
        //Ward Porter thread
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run()
            {
                try {
                    pc.wardPorter();
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
 
        //Start both threads
        t1.start();
        t2.start();
 
        t1.join();
        t2.join();
    }
 

    public static class PC {

        //List with a capacity of 6 representing the room between the ambulance and ward porter
        LinkedList<Integer> list = new LinkedList<>();
        int capacity = 6;
 
        //Function called by Ambulance Porter thread
        public void ambulancePorter() throws InterruptedException
        {
            int value = 1;
            int patients = 0;
          
            while (patients != 20) {
                synchronized (this)
                {
                    //Ambulance Porter thread waits while capacity is full
                    while (list.size() == capacity)
                        wait();
                    
                    //Prints out what patient was added to the room and how many beds are taken
                    System.out.println("Patient " + value + " added to the room, " + (list.size() + 1) + " patients in beds");
 
                    //Inserts the pateint to the list
                    list.add(value++);
 
                    //Notifies the ward porter thread that it can start removing patients
                    notify();
 
                    Thread.sleep(1000);
                  
                    patients ++;
                    
                    //If all the beds in the room are taken then a print statement notifies that the room is full
                    if (list.size() == capacity){
                        System.out.println("Room is full");
                    }
                }
            }
        }
 
        //Function called by Ward Porter thread
        public void wardPorter() throws InterruptedException
        {
            int patients = 0;
            while (true) {
                synchronized (this)
                {
                    //Ward porter list waits while the room is empty
                    while (list.size() == 0)
                        wait();
 
                    //Retrieves the first patient in the list
                    int val = list.removeFirst();
 
                    //Prints what patient has been removed from the room and how many beds are taken
                    System.out.println("Patient " + val + " removed from room, " + list.size() + " patients in beds");
 
                    //Wakes up the Ambulance Porter thread
                    notify();
 
                    Thread.sleep(1000);
                    
                    patients++;
                    
                    //Prints that the ward is empty if capacity is 0 and ends the programme after 20 patients
                      if (list.size() == 0){
                        System.out.println("Room is empty");
                    } if (patients == 20){
                        System.exit(0);
                    }
                    
                }
            }
        }
    }
}